<!doctype html>
<!--[if lt IE 7 ]><html lang="en" class="no-js ie6"><![endif]-->
<!--[if IE 7 ]><html lang="en" class="no-js ie7"><![endif]-->
<!--[if IE 8 ]><html lang="en" class="no-js ie8"><![endif]-->
<!--[if IE 9 ]><html lang="en" class="no-js ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang="en" class="no-js"><!--<![endif]-->
<head>
	<meta charset="utf-8">
	<title>E-Minutes | A Platform For Your Minutes</title>
	<meta name="description" content="flexi auth, the user authentication library designed for developers."/> 
	<meta name="keywords" content="flexi auth, user authentication, codeigniter"/>
	<?php $this->load->view('includes/head'); ?> 
</head>

<body id="home">

<div id="body_wrap">
	<!-- Header -->  
	<?php $this->load->view('includes/header'); ?> 

	<!-- Intro Content -->
	<div class="content_wrap nav_bg main_banner">
		<div class="content clearfix">
			<img src="<?php echo $includes_dir;?>images/flexi_auth_traffic_sign.png" class="main_banner_img"/>		
			<div id="banner_wrap" class="w66 float_r align_ctr">
				<h1></h1>
				
			</div>		
		</div>
	</div>

	<div class="content_wrap intro_bg">
		<div class="content clearfix">
			<div class="w100">
				<h3> E-Minutes</h3>
				
				<hr style="margin-top:10px; margin-bottom:10px; border:none; border-top:1px dotted #999;"/>
				
                <p>An online minutes system that provides a medium for secretary or workers to keep their details information of minutes via the online system. By using the system, users can gain such an organize management of the daily works schedule and have an access to the data whenever they need.</p>
                
			</div>
		</div>
	</div>

	<!-- Main Content -->
	<div class="content_wrap main_content_bg">
		<div class="content clearfix">
					
			<div class="w100 frame">
				<h2>More About E-Minutes</h2>
				
				<p></p>
				<hr/>
				
				<p>Your data more secure with the use of session expiration after idle</p>
				<p></p>
				<hr/>
				
				<p></p>
			</div>
			
		</div>
	</div>
</div>
    
    
   
<!-- Footer -->  
<?php $this->load->view('includes/footer'); ?> 

<!-- Scripts -->  
<?php $this->load->view('includes/scripts'); ?> 

</body>
</html>