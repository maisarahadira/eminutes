<!doctype html>
<!--[if lt IE 7 ]><html lang="en" class="no-js ie6"><![endif]-->
<!--[if IE 7 ]><html lang="en" class="no-js ie7"><![endif]-->
<!--[if IE 8 ]><html lang="en" class="no-js ie8"><![endif]-->
<!--[if IE 9 ]><html lang="en" class="no-js ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang="en" class="no-js"><!--<![endif]-->
<head>
	<meta charset="utf-8">
	<title>Manage Addresses Demo | flexi auth | A User Authentication Library for CodeIgniter</title>
	<meta name="description" content="flexi auth, the user authentication library designed for developers."/> 
	<meta name="keywords" content="demo, flexi auth, user authentication, codeigniter"/>
	<?php $this->load->view('includes/head'); ?> 
</head>

<body id="manage_minutes">

<div id="body_wrap">
	<!-- Header -->  
	<?php $this->load->view('includes/header'); ?> 

	<!-- Demo Navigation -->
	<?php $this->load->view('includes/user_header'); ?> 
	
	
	
	<!-- Main Content -->
	<div class="content_wrap main_content_bg">
		<div class="content clearfix">
			<div class="col100">
				<h2>Minutes View</h2>
				<a href="<?php echo $base_url;?>auth_public/insert_minutes">Insert New Minutes</a>

			<?php if (! empty($message)) { ?>
				<div id="message">
					<?php echo $message; ?>
				</div>
			<?php } ?>
				
				<?php echo form_open(current_url());	?>  	
					<table>
						<thead>
							<tr>
								<th class="spacer_150 tooltip_trigger">
									Minutes Title
								</th>
								
								<th class="spacer_100 align_ctr tooltip_trigger">
									Date
								</th>
                                <th class="spacer_100 align_ctr tooltip_trigger">
									Delete
								</th>
							</tr>
						</thead>
						<?php 
							if (!empty($minutess)) {
								foreach ($minutess as $minutes) {
						?>
						<tbody>
							<tr>
								<td>
									<a href="<?php echo $base_url;?>auth_public/update_minutes/<?php echo $minutes['umin_id'];?>/"><?php echo $minutes['umin_title'];?></a>
								</td>
								<td><?php echo $minutes['umin_date_added'];?></td>
								
								
								<td class="align_ctr">
									<input type="checkbox" name="delete_minutes[<?php echo $minutes['umin_id'];?>]" value="1"/>
								</td>
							</tr>
						</tbody>
						<?php } ?>
						<tfoot>
							<tr>
								<td colspan="5">
									<input type="submit" name="update_minutess" value="Delete Checked Minutess" class="link_button large"/>
								</td>
							</tr>
						</tfoot>
						<?php } else { ?>
						<tbody>
							<tr>
								<td colspan="5">
									<p>There are no minutes in your minutes table</p>
								</td>
							</tr>
						</tbody>
						<?php } ?>
					</table>
				<?php echo form_close();?>
			</div>
		</div>
	</div>	
	
	<!-- Footer -->  
	<?php $this->load->view('includes/footer'); ?> 
</div>

<!-- Scripts -->  
<?php $this->load->view('includes/scripts'); ?> 

</body>
</html>