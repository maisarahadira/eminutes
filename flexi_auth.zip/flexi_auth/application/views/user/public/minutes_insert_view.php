<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<script src="<?php echo base_url('assets/ckeditor/ckeditor.js'); ?>"></script>
    <script>UPLOADCARE_PUBLIC_KEY = 'hehehe'</script>
    <?php $this->load->view('includes/head'); ?> 
	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
    
    
    
    <body id="insert_address">

<div id="body_wrap">
	<!-- Header -->  
	<?php $this->load->view('includes/header'); ?> 

	<!-- Demo Navigation -->
	<?php $this->load->view('includes/user_header'); ?> 
	
	
	
	<!-- Main Content -->
	<div class="content_wrap main_content_bg">
		<div class="content clearfix">
			<div class="col100">
				<h2>Insert New Address</h2>
				<a href="<?php echo $base_url;?>auth_public/manage_address_book">Manage Address Book</a>

			<?php if (! empty($message)) { ?>
				<div id="message">
					<?php echo $message; ?>
				</div>
			<?php } ?>
				
				<?php echo form_open(current_url());	?>
					<li class="info_req">
								<label for="minutes_title">Title:</label>
								<input type="text" id="minutes_title" name="insert_minutes_title" value="<?php echo set_value('insert_minutes_title');?>"/>
                                
							</li>
							<li>
                            <form action="" method="post">
                            <textarea name="editor1" id="editor1" rows="10" cols="80" value="<?php echo set_value('editor1');?>"></textarea>
                            
                            </li>
                                
                                <li>
								
								<label for="submit">Insert Minutes:</label>
								<input type="submit" name="insert_minutes" id="submit" value="Submit" class="link_button large"/>
							</li>
				<?php echo form_close();?>
			</div>
		</div>
	</div>	
    
    
    <!-- Footer -->  
	<?php $this->load->view('includes/footer'); ?> 
</div>

<!-- Scripts -->  
<?php $this->load->view('includes/scripts'); ?> 
   </body>
 
    
 
<script>

    CKEDITOR.replace('editor1' ,{
		filebrowserImageBrowseUrl : '<?php echo base_url('assets/filemanager/index.html');?>'
	});
            </script>
</html>