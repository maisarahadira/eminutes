	<div class="content_wrap footer_bg">
		<div id="footer" class="content clearfix">
			
			<div class="float_l" style="margin-top:20px; text-align:center;">
				Copyright &copy; <?php echo date('Y');?>, E-Minutes by Nur Maisarah Adira, UTHM Student.<br/><br/>
			</div>
		</div>
	</div>

