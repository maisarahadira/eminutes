	<div class="content_wrap nav_bg">
		<div id="sub_nav_wrap" class="content">
			<ul id="sub_nav">
				
				<li class="css_nav_dropmenu">
					<a href="<?php echo $base_url;?>auth_admin/">Admin Dashboard</a>
					<ul>
						
						<li class="header">Select Feature to Manage</li>
						<li>
							<a href="<?php echo $base_url;?>auth_admin/manage_user_accounts">Manage User Accounts</a>			
						</li>
											
						<li>
							<a href="<?php echo $base_url;?>auth_admin/list_user_status/active">List Active Users</a>
						</li>	
						<li>
							<a href="<?php echo $base_url;?>auth_admin/list_user_status/inactive">List Inactive Users</a>
						</li>	
						<li>
							<a href="<?php echo $base_url;?>auth_admin/delete_unactivated_users">List Unactivated Users</a>
						</li>	
						<li>
							<a href="<?php echo $base_url;?>auth_admin/failed_login_users">List Failed Logins</a>			
						</li>	
					</ul>		
				</li>
                        
			
				<li class="css_nav_dropmenu">
					<a href="<?php echo $base_url;?>auth_admin/profile_dashboard">Admin Account</a>
					<ul>
						<li class="header">Select Feature to Manage</li>
						<li>
							<a href="<?php echo $base_url;?>auth_admin/update_account">Update Account Details</a>
						</li>
						<li>
							<a href="<?php echo $base_url;?>auth_admin/update_email">Update Email Address</a>
						</li>
						<li>
							<a href="<?php echo $base_url;?>auth_admin/change_password">Update Password</a>
						</li>
						<li>
							<a href="<?php echo $base_url;?>auth_admin/manage_address_book">Manage Address Book</a>
						</li>
					</ul>		
				</li>
				                
                
                
                <?php if (! $this->flexi_auth->is_logged_in_via_password()) { ?>
				<li>
					<a href="<?php echo $base_url;?>auth"><?php echo ($this->flexi_auth->is_logged_in()) ? 'Login via Password' : 'Login';?></a>
				</li>
				
			<?php } ?>
			<?php if (! $this->flexi_auth->is_logged_in()) { ?>
				
			<?php } else { ?>
				<li>
					<a href="<?php echo $base_url;?>auth/logout">Logout</a>
				</li>
			<?php } ?>
                
<script>
    var secs = 10*60;
    var active = setTimeout("logout()",(secs*1000));
    function logout()
    {
       
       
alert('Your session have been expired. You will be directed to login page.')
        window.location.href='<?php echo $base_url;?>auth/logout';
        
    }
</script>
                
			</ul>
		</div>
	</div>




