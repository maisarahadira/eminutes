<script>
	// Hide content onload, prevents JS flicker
	document.body.className += ' js-enabled';
</script>

<div id="header_wrap">
	<div id="header">
		<h1 id="logo">
			<a href="<?php echo $base_url; ?>" title="E-MESYUARAT">
				
			</a>
		</h1>
		 
		<ul id="nav">
			<li>
				<a href="<?php echo $base_url;?>">Home</a>
			</li>
			
			<li>
				<a href="<?php echo $base_url;?>auth/login">Login/Register</a>
			</li>
		</ul> 

		
	</div>
</div>